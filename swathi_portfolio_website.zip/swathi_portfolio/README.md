# Swathi V — Portfolio Website

A responsive personal portfolio made with plain HTML, CSS, and JavaScript. It includes gradient styling, responsive navigation, scroll reveal effects, skills, and a featured SANA project card.

## Files
- `index.html` — page content
- `style.css` — layout, colors, responsive design, and animations
- `script.js` — mobile menu, reveal animations, and current year

## Run locally
Open `index.html` in a browser. No build tools or installation are required.

## Before publishing
1. Replace `YOUR_EMAIL@example.com` in `index.html` with a contact email you want to publish.
2. Review your name, education, skills, and project description for accuracy.
3. Add genuine screenshots of SANA if you want to replace the illustrative project mockup.
4. Check that all public links and any personal details are correct.

## Publish
Create a separate GitHub repository for the portfolio, upload these files, then go to **Settings → Pages** and select **Deploy from a branch**, branch `main`, folder `/(root)`, and click **Save**. GitHub Pages supports static HTML, CSS, and JavaScript sites. See https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
